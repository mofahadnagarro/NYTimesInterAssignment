package com.NY.helperClasses;

import com.NY.locators.LocatorReader;
import com.NY.utils.CommonComponents;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.text.SimpleDateFormat;
import java.util.*;

public class NYTHomePageHelper extends CommonComponents {

    private LocatorReader element;

    public NYTHomePageHelper(WebDriver driver, WebDriverWait wait) {
        super(driver, wait);
        element = new LocatorReader("web_locators.xml");
    }

    public void verifyNYTNavigation(String pageTitle){
        try {
            if (driver.getTitle().equalsIgnoreCase(pageTitle)){

                attachScreenshotToReport("Successfully navigated to news website","positive");

            }else {

                attachScreenshotToReport("Something went wrong... page title doesn't matched. EXPECTED: "+pageTitle+" BUT FOUND: "+driver.getTitle(),"negative");

            }

        } catch (Exception e) {
            attachScreenshotToReport("Exception occurred "+e.getMessage(),"negative" );
        }
    }

    public String getNewspaperEditionDate(){
        String date="";
        try {

            waitForElementToVisible(element.getLocator("HomePage.TodaysDate"),20);
            if (isElementPresent(element.getLocator("HomePage.TodaysDate"))){
                date = getText(element.getLocator("HomePage.TodaysDate"));
            }

        }catch (Exception e){
            attachScreenshotToReport("Exception occurred "+e.getMessage(),"negative" );
        }
        return date;
    }

    public String getTodaysDate(){
        String todayDate = "";

        try {
            SimpleDateFormat formatter = new SimpleDateFormat("EEEE, MMMM d, yyyy");
            Date date = new Date();
            todayDate = formatter.format(date);
        }catch (Exception e){
            attachScreenshotToReport("Exception occurred "+e.getMessage(),"negative" );
        }

        return todayDate;
    }

    public void verifyCurrentNewsPaperEdition(){

        try{

            if (getNewspaperEditionDate().equalsIgnoreCase(getTodaysDate())){

                attachScreenshotToReport("User is on today's edition, which is --> "+getNewspaperEditionDate(),"positive");
            }else {
                attachScreenshotToReport("Failed to navigate on today's news edition","negative");
            }

        }catch (Exception e){
            attachScreenshotToReport("Exception occurred "+e.getMessage(),"negative" );
        }

    }

    public void verifyAndClickOnSearchIcon(){
        try{
            waitForElementToVisible(element.getLocator("HomePage.SearchIcon"),10);
            if (isElementPresent(element.getLocator("HomePage.SearchIcon"))){

                clickOn(element.getLocator("HomePage.SearchIcon"));

            }else {
                attachScreenshotToReport("Search icon is not present on page","negative");
            }
        }catch(Exception e){
            attachScreenshotToReport("Exception occurred "+e.getMessage(),"negative" );
        }
    }

    public void verifyAndEnterTextInToSearchField(String str_input){

        try{
            waitForElementToVisible(element.getLocator("HomePage.SearchTextField"),10);
            if (isElementPresent(element.getLocator("HomePage.SearchTextField"))){

                sendKeys(element.getLocator("HomePage.SearchIcon"),str_input);

            }else {
                attachScreenshotToReport("Search field is not present on page","negative");
            }
        }catch(Exception e){
            attachScreenshotToReport("Exception occurred "+e.getMessage(),"negative" );
        }

    }

    public void verifyAndClickOnGoButton(){

        try{
            waitForElementToVisible(element.getLocator("HomePage.GOButton"),10);
            if (isElementPresent(element.getLocator("HomePage.GOButton"))){

                clickOn(element.getLocator("HomePage.GOButton"));

            }else {
                attachScreenshotToReport("GO button is not present on page","negative");
            }
        }catch(Exception e){
            attachScreenshotToReport("Exception occurred "+e.getMessage(),"negative" );
        }
    }

    public List<String> getAllHeadlinesFromTheSearchResultPage(){

        List<String> list_headlines = new ArrayList<String>();

        try{
            waitForElementsToVisible(element.getLocator("SearchResultPage.SearchResultList"),20);
            List<WebElement> list_ele_headlines = driver.findElements(ByLocator(element.getLocator("SearchResultPage.SearchResultList")));
            for (WebElement ele: list_ele_headlines){

                if (!ele.getText().equalsIgnoreCase(" ")||!ele.getText().equalsIgnoreCase("")){
                    list_headlines.add(ele.getText());
                }
            }

        }catch(Exception e){

            attachScreenshotToReport("Exception occurred "+e.getMessage(),"negative" );
        }
        return list_headlines;
    }

    public void verifyRelevantResultsOnSearchPage(List<String> list){
        try{
            boolean flag = false;
            if (list == null || list.isEmpty()) {
                flag = false;
            }

            Map<String, Integer> wordCountMap = new HashMap<>();

            // Iterate over each element in the list and count the words
            for (String element : list) {
                if (element != null) {
                    String[] words = element.split("\\s+");
                    for (String word : words) {
                        wordCountMap.put(word, wordCountMap.getOrDefault(word, 0) + 1);
                    }
                }
            }

            int halfSize = list.size() / 2;

            // Check if any word's count is at least 50% of the list size
            for (Map.Entry<String, Integer> entry : wordCountMap.entrySet()) {
                if (entry.getValue() >= halfSize) {
                    flag = true;
                }
            }

            if(flag){
                attachScreenshotToReport("Showing relevant search result","positive");
            }else {

                attachScreenshotToReport("Showing irrelevant search result","negative");
            }



        }catch(Exception e){

            attachScreenshotToReport("Exception occurred "+e.getMessage(),"negative" );
        }
    }

}
