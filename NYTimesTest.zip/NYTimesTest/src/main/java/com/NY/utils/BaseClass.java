package com.NY.utils;

import com.NY.helperClasses.NYTHomePageHelper;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.bouncycastle.tsp.TSPUtil;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.NY.utils.ExtentManager;
import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.*;

import java.lang.reflect.Method;

public abstract class BaseClass {

    public WebDriver driver;
    public WebDriverWait wait;
    public ExtentReports extentReports;
    public ExtentTest extentTest;
    public static ExcelReader excel;
    public static String browserName;
    public static String appURL;
    public NYTHomePageHelper homePageHelper;
    public static String testCase_name="";
    protected static ExtentReports extent;
    public static ThreadLocal<ExtentTest> exTest = new ThreadLocal<ExtentTest>();
    public static ExtentTest test;


    @BeforeSuite
    public void dataSetup(){

        excel = new ExcelReader(Constants.SUITE1_XL_PATH);
        browserName = excel.getCellData("TestSet","Browser",2);
        appURL = excel.getCellData("TestSet","URL",2);
        extent = ExtentManager.GetExtent();

    }

    @Parameters({"browser","url"})
    @BeforeTest
    public void invokeTest(String browser, String appurl){

        startBrowser(appURL,browserName);
        homePageHelper = new NYTHomePageHelper(driver,wait);

    }

    @BeforeMethod
    public void createTestDescription(Method method) {

        testCase_name = method.getName();
    }

    @AfterSuite
    public void afterTestSuite() {

        ExtentManager.GetExtent().flush();

    }

    /*@AfterTest
    public void close(ITestResult result){
        teardownWebDriver(result);
        homePageHelper = null;
    }*/

    public void startBrowser(String appURL, String browserName) {
        try {
            System.out.println("Browsername from sheet >>> "+browserName);
            String browser = browserName; // Default to Chrome if no browser specified
            switch (browser.toLowerCase()) {
                case "chrome":
                    ChromeOptions option = new ChromeOptions();
                    option.addArguments("--remote-allow-origins=*");
                    option.addArguments("disable-infobars");
                    option.addArguments("--disable-save-password-bubble");
                    WebDriverManager.chromedriver().setup();
                    driver = new ChromeDriver(option);
                    driver.manage().window().maximize();
                    wait = new WebDriverWait(driver,10);
                    driver.get(appURL);
                    //extentReports = ExtentManager.getInstance();
                  //  extentTest = ExtentManager.createTest(result.getName());

                    break;
                case "firefox":
                    WebDriverManager.firefoxdriver().setup();
                    driver = new FirefoxDriver();
                    wait = new WebDriverWait(driver,10);
                    driver.get(appURL);
                  //  extentReports = ExtentManager.getInstance();
                //    extentTest = ExtentManager.createTest(result.getName());
                    homePageHelper = new NYTHomePageHelper(driver,wait);
                    break;
                default:
                  //  throw new IllegalArgumentException("Unsupported browser: " + browser);
            }

            //   extentReports = ExtentManager.getInstance();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void teardownWebDriver(ITestResult result) {
        if (driver != null) {
            if (ITestResult.FAILURE == result.getStatus()) {
                //    newsHelper.captureScreenshot(scenario.getName());
                extentTest.fail("'"+result.getName()+"' -->> "+"Failed");
            }
            extentReports.flush();
            driver.quit();
        }
    }

    public void setTestCaseDescription(String testCase_name, String test_description) {
        test = ExtentManager.createTest(testCase_name + " - " + test_description,
                " is tested on " + this.browserName + " with version:  >> Test Description - " + "<b>" + test_description + "</b>" + "");

        setExtentTest(test);

    }

    public void checkExecution(String dataRunMode, String testCaseName) {
        if (dataRunMode.equalsIgnoreCase(Constants.RUNMODE_NO)) {

            test.skip("Run Mode is set to 'No'.. Test Case got SKIPPED.");
            throw new SkipException("Skipping the Test : " + testCaseName + " as the Runmode of Test Data is No");
        }

    }

    public void setExtentTest(ExtentTest et) {

        exTest.set(et);
    }

    public ExtentTest getExtTest() {

        return exTest.get();
    }

}
