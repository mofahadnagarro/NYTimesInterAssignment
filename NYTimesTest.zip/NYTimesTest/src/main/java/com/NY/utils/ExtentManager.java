package com.NY.utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentManager {
    private static ExtentReports extent;
    private static ExtentTest test;
    private static ExtentHtmlReporter htmlReporter;

    public Constants constants = new Constants();

    private static String filePath = System.getProperty("user.dir")+"/TestReports/index.html";



    public static ExtentReports GetExtent(){
        if (extent != null)
            return extent; //avoid creating new instance of html file
        extent = new ExtentReports();
        extent.attachReporter(getHtmlReporter());
        extent.setSystemInfo("Developed By", "Mohd Fahad");
        return extent;
    }

    private static ExtentHtmlReporter getHtmlReporter() {
        htmlReporter = new ExtentHtmlReporter(filePath);
        htmlReporter.loadConfig("./extent-config.xml");
        htmlReporter.config().setDocumentTitle("NY Times Test Automation Report");
        htmlReporter.config().setReportName("Testing cycle");
        htmlReporter.config().setTheme(Theme.STANDARD);

        return htmlReporter;
    }

    public static ExtentTest createTest(String name, String description){
        test = extent.createTest(name, description);
        return test;
    }


}
