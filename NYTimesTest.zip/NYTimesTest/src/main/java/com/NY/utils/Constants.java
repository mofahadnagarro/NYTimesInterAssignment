package com.NY.utils;

public class Constants {

    public static final String SUITE1_XL_PATH = System.getProperty("user.dir")+"/TestData/TestDataSheet.xlsx";

    public static final String RUNMODE_YES = "Yes";
    public static final String TEST_CASE_SHEET = "TestCase";
    public static final String TEST_CASE_COL = "TCID";
    public static final String TEST_RUNMODE_COL = "RunMode";
    public static final String RUNMODE_NO = "No";

}
