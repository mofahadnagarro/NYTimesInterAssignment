package com.NY.testScripts;

import com.NY.utils.BaseClass;
import com.NY.utils.DataProviders;
import org.testng.annotations.Test;

import java.util.Hashtable;

public class NYTBasicTests extends BaseClass {

    @Test(dataProviderClass = DataProviders.class, dataProvider = "NYTimesTest", description = "Verify the New york times home page")
    public void TC_001(Hashtable<String, String> data) {

        setTestCaseDescription(testCase_name,data.get("Description"));

        checkExecution(data.get("Run Mode"), testCase_name);

        homePageHelper.verifyNYTNavigation(data.get("Page Title"));

    }

    @Test(dataProviderClass = DataProviders.class, dataProvider = "NYTimesTest", description = "Verify if user is on current news paper edition")
    public void TC_002(Hashtable<String, String> data) {

        setTestCaseDescription(testCase_name,data.get("Description"));

        checkExecution(data.get("Run Mode"), testCase_name);

        homePageHelper.verifyCurrentNewsPaperEdition();

    }

    @Test(dataProviderClass = DataProviders.class, dataProvider = "NYTimesTest", description = "Verify that if search feature is working on home screen")
    public void TC_003(Hashtable<String, String> data) {

        setTestCaseDescription(testCase_name,data.get("Description"));

        checkExecution(data.get("Run Mode"), testCase_name);

        homePageHelper.verifyAndClickOnSearchIcon();

        homePageHelper.verifyAndEnterTextInToSearchField(data.get("Search Query"));

        homePageHelper.verifyAndClickOnGoButton();


    }

    @Test(dataProviderClass = DataProviders.class, dataProvider = "NYTimesTest", description = "Verify that if relevant result received on result page")
    public void TC_004(Hashtable<String, String> data) {

        setTestCaseDescription(testCase_name,data.get("Description"));

        checkExecution(data.get("Run Mode"), testCase_name);

        homePageHelper.verifyRelevantResultsOnSearchPage(homePageHelper.getAllHeadlinesFromTheSearchResultPage());


    }



}
